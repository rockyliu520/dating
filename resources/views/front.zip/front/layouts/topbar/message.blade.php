<a class="messages-popup" href="page1.html">
	<i class="fa fa-envelope-o"></i>
	<span class="noto-count">4</span>
</a>
<div class="noto-popup messages-block">
    <div class="m-close"><i class="fa fa-times"></i></div>
	<div class="noto-label">Your Messages <span class="noto-label-links"><a href="messages-2.html">compose</a><a href="messages.html">View all messages</a></span></div>
	<div class="noto-body">
		<div class="noto-entry style-2">
			<div class="noto-content clearfix">
				<div class="noto-img">	
					<a href="page1.html">
						<img src="{{ $url }}/img/c1.png" alt="" class="be-ava-comment">
					</a>
				</div>
				<div class="noto-text">
					<div class="noto-text-top">
						<span class="noto-name"><a href="page1.html">Ravi Sah</a></span>
						<span class="noto-date"><i class="fa fa-clock-o"></i> May 27, 2015</span>
					</div>
					<div class="noto-message">Sed velit mauris, pulvinar sit amet accumsan vitae, egestas, pulvinar sit amet accumsan vitae, egestas</div>
				</div>
			</div>
		</div>
		<div class="noto-entry style-2">
			<div class="noto-content clearfix">
				<div class="noto-img">	
					<a href="page1.html">
						<img src="{{ $url }}/img/c6.jpg" alt="" class="be-ava-comment">
					</a>
				</div>
				<div class="noto-text">
					<div class="noto-text-top">
						<span class="noto-name"><a href="page1.html">Louis Paquet</a></span>
						<span class="noto-date"><i class="fa fa-clock-o"></i> May 27, 2015</span>
					</div>
					<div class="noto-message">
					Pellentesque habitant morbi tristique senectus et netus tristique senectus
					</div>
				</div>
			</div>
		</div>
		<div class="noto-entry style-2">
			<div class="noto-content clearfix">
				<div class="noto-img">	
					<a href="page1.html">
						<img src="{{ $url }}/img/c9.jpg" alt="" class="be-ava-comment">
					</a>
				</div>
				<div class="noto-text">
					<div class="noto-text-top">
						<span class="noto-name"><a href="page1.html">Cüneyt ŞEN</a></span>
						<span class="noto-date"><i class="fa fa-clock-o"></i> May 27, 2015</span>
					</div>
					<div class="noto-message">
						Sed id erat vitae libero malesuada dictum vel sit amet eros
					</div>
				</div>
			</div>
		</div>								
		<div class="noto-entry style-2">
			<div class="noto-content clearfix">
				<div class="noto-img">	
					<a href="page1.html">
						<img src="{{ $url }}/img/c10.jpg" alt="" class="be-ava-comment">
					</a>
				</div>
				<div class="noto-text">
					<div class="noto-text-top">
						<span class="noto-name"><a href="page1.html">Tomasz Mazurczak</a></span>
						<span class="noto-date"><i class="fa fa-clock-o"></i> May 27, 2015</span>
					</div>
					<div class="noto-message">
						In molestie libero quis cursus ullamcorper eu rhoncus magna
					</div>
				</div>
			</div>
		</div>												
	</div>							
</div>