
<style type="text/css">
	#content-block {
		margin-bottom: 0px !important;
	}
	.footer_slider {
		background: #2e3542;
	}
</style>
<?php $__env->startSection('index'); ?>
	
	<div class="head-bg">
		<div class="head-bg-img"></div>
		<div class="head-bg-content">
			<h1>寂寞先生</h1>
			<p>每个人都有属于自己的艳遇</p>
			<!-- <a class="btn color-1 size-1 hover-1" ><i class="fa fa-facebook"></i>sign up via facebook</a> -->
			<?php if(!Auth::check()): ?>
				<a class="be-register btn color-3 size-1 hover-6"><i class="fa fa-lock"></i>现在注册账号</a>
			<?php endif; ?>
		</div>
	</div>
	<!-- <?php echo $__env->make('front.home.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
	<div class="container-fluid custom-container">
		<div class="row">
			
			<?php echo $__env->make('front.home.leftfilter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<div class="col-md-10">
				<div id="container-mix"  class="row _post-container_">
					<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="category-1 mix custom-column-5">
							<div class="be-post">
								<a href="/detail/<?php echo e($u->id); ?>" class="be-img-block">
									<?php if($u->image == ''): ?>
										<img src="/img/users/1.jpg" alt="omg">
									<?php else: ?>
										<img src="<?php echo e($u->image); ?>" alt="omg">
									<?php endif; ?>
								</a>
								<?php 
									$year = date('Y');
									$age = $year - $u->year; 
								?>
								<a href="/detail/<?php echo e($u->id); ?>" class="be-post-title"><?php echo e($u->fname); ?>, <?php echo e($age); ?>岁</a>
								
								<span>
									<?php if($u->sex == 'male'): ?>
										男
									<?php else: ?>
										女
									<?php endif; ?>
									, <?php echo e($u->location); ?>, 澳大利亚
									<!-- <a href="blog-detail-2.html" class="be-post-tag">Interaction Design</a>, 
									<a href="blog-detail-2.html" class="be-post-tag">UI/UX</a>,  
									<a href="blog-detail-2.html" class="be-post-tag">Web Design</a> -->
								</span>
								<!-- <div class="author-post">
									<img src="/img/a1.png" alt="" class="ava-author">
									<span>by <a href="page1.html">Hoang Nguyen</a></span>
								</div> -->
								<div class="info-block">
									<!-- <span><i class="fa fa-thumbs-o-up"></i> 360</span> -->
									<span><i class="fa fa-eye"></i> 789</span>
									<!-- <span><i class="fa fa-comment-o"></i> 20</span> -->
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>

		</div>
	</div>
	<div class="footer_slider">
		<div class="swiper-container" data-autoplay="0" data-loop="1" data-speed="500" data-center="0" data-slides-per-view="responsive" data-xs-slides="4" data-sm-slides="8" data-md-slides="14" data-lg-slides="19" data-add-slides="19">
            <div class="swiper-wrapper">
            	<?php $__currentLoopData = $random; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            	<div class="swiper-slide active" data-val="0">
						<a href="/detail/<?php echo e($r->id); ?>">
							<img class="img-responsive img-full" src="<?php echo e($r->image); ?>" alt="">
	            	 	</a>
            	 	</div>
        	 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="pagination hidden"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>