<?php echo $__env->make('front.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('front.layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="app">
	<div id="loader-wrapper" style="display:none">
	    <div id="loader"></div>
	    <!-- <div class="loader-section section-left"></div> -->
	    <div class="loader-section section-right"></div>
	</div>
<?php echo $__env->yieldContent('index'); ?>
</div>
<?php echo $__env->make('front.layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>