
<style>
	@import  url(https://fonts.googleapis.com/css?family=Exo:400,500,500italic,400italic,600,600italic,700,700italic,800,800italic,300,300italic);
	body {
		/*The below background is just to add some color, you can set this to anything*/
	  	background: url('/images/bg3.jpg') center center no-repeat;
	}
	#navbar {
		background: none;
	}
</style>
<?php $__env->startSection('index'); ?>
<div class="container register-form" id="signup">
	<h2 class="login-title">- 账号注册 -</h2>
	<div class="panel panel-default">
		<div class="panel-body">
			<form method="post" action="/account/register" id="signupform">
				<?php echo e(csrf_field()); ?>

				<div class="input-group register-userinput">
					<span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
					<input id="userEmail" type="email" class="form-control " name="email" placeholder="输入你的邮箱" required="required">
				</div>
				<div class="input-group register-userinput">
					<span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
					<input id="reUserEmail" type="email" class="form-control " name="re-email" placeholder="确认你的邮箱" required="required">
				</div>
				<div class="input-group register-userinput">
					<span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
					<input  id="txtPassword" type="password" class="form-control " name="password" placeholder="输入您的密码" required="required">
					<span id="showPassword" class="input-group-btn">
            			<button class="btn btn-default reveal" type="button"><i class="glyphicon glyphicon-eye-open"></i></button>
          			</span>  
				</div>
				<div class="input-group register-userinput sexChoose">
					<label>您的性别</label>&nbsp;&nbsp;&nbsp;&nbsp;
					<label class="radio-inline">
						<input type="radio" name="sex" value="male" checked="checked"> &nbsp;&nbsp;男&nbsp;&nbsp;
					</label>
					<label class="radio-inline">
						<input type="radio" name="sex" value="female"> &nbsp;&nbsp;女&nbsp;&nbsp;
					</label>
				</div>
				<?php if(Session::has('errorMessage')): ?>
					<div class="alert alert-danger">
						<?php echo e(Session::get('errorMessage')); ?>

					</div>
				<?php endif; ?>
				<button class="btn btn-primary btn-block register-button" type="submit"><i class="fa fa-sign-in"></i> 现在注册</button>
				<div class="checkbox register-options">
					<a href="/account/siginin" class="register-forgot">我有账号, 去登陆</a>
				</div>		
			</form>			
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>