
<style>
	@import  url(https://fonts.googleapis.com/css?family=Exo:400,500,500italic,400italic,600,600italic,700,700italic,800,800italic,300,300italic);
	body {
		/*The below background is just to add some color, you can set this to anything*/
	  	background: url('/images/bg3.jpg') center center no-repeat;
	}
	#navbar {
		background: none;
	}
</style>
<?php $__env->startSection('index'); ?>
<div class="container login-form" id="signin">
	<h2 class="login-title">- 账号登录 -</h2>
	<div class="panel panel-default">
		<div class="panel-body">
			<form method="post" action="/account/login" id="signinform">
				<?php echo e(csrf_field()); ?>

				<div class="input-group login-userinput">
					<span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
					<input id="txtUser" type="email" class="form-control " name="email" placeholder="输入你的邮箱" required="required">
				</div>
				<div class="input-group login-userinput">
					<span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
					<input  id="txtPassword" type="password" class="form-control " name="password" placeholder="输入您的密码" required="required">
					<span id="showPassword" class="input-group-btn">
            			<button class="btn btn-default reveal" type="button"><i class="glyphicon glyphicon-eye-open"></i></button>
          			</span>  
				</div>
				<?php if(Session::has('errorMessage')): ?>
					<div class="alert alert-danger">
						<?php echo e(Session::get('errorMessage')); ?>

					</div>
				<?php endif; ?>
				<button class="btn btn-primary btn-block login-button" type="submit"><i class="fa fa-sign-in"></i> 现在登录</button>
				<div class="checkbox login-options">
					<label><input type="checkbox"/>记住我</label>
					<a href="#" class="login-forgot">忘记密码</a>
				</div>		
			</form>
			<a class="btn btn-primary" data-toggle="modal" href='#modal-id'>Trigger modal</a>
				<div class="modal fade" id="modal-id">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
								<h4 class="modal-title">Modal title</h4>
							</div>
							<div class="modal-body">
								
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="button" class="btn btn-primary">Save changes</button>
							</div>
						</div>
					</div>
				</div>	
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>