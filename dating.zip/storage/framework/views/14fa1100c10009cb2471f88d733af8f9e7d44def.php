
	<script type="text/javascript" src="<?php echo e(URL::asset('js/app.js')); ?>"></script>		
	</body>
</html>