
	<script type="text/javascript" src="{{ URL::asset('js/app.js') }}"></script>		
	</body>
</html>