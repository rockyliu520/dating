@extends('front.layouts.main')
<style>
	@import url(https://fonts.googleapis.com/css?family=Exo:400,500,500italic,400italic,600,600italic,700,700italic,800,800italic,300,300italic);
	body {
		/*The below background is just to add some color, you can set this to anything*/
	  	background: url('/images/bg3.jpg') center center no-repeat;
	}
	#navbar {
		background: none;
	}
	.modal-backdrop {
		display: none;
	}
</style>
@section('index')
<div id="dashboard">
	<div class="container">
		<div class="row">
			@include('front.account.include.info')
			@include('front.account.include.sidebar')
			<div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 rightPart">
				@if(Auth::user()->image == '')
					<div class="alert alert-warning">
						<h3>您还没有上传头像, 请上传头像</h3>
					</div>
				@endif

				<button type="button" class="btn btn-primary"  data-toggle="modal" data-target="#avatar-modal" style="margin: 10px;">
						修改头像
				</button>
				<div class="user_pic" style="margin: 10px;">
					<img src=""/>
				</div>

				<div class="modal fade" id="avatar-modal" aria-hidden="true" aria-labelledby="avatar-modal-label" role="dialog" tabindex="-1">
					<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<!--<form class="avatar-form" action="upload-logo.php" enctype="multipart/form-data" method="post">-->
							<form class="avatar-form">
								<div class="modal-header">
									<button class="close" data-dismiss="modal" type="button">&times;</button>
									<h4 class="modal-title" id="avatar-modal-label">上传图片</h4>
								</div>
								<div class="modal-body">
									<div class="avatar-body">
										<div class="avatar-upload">
											<input class="avatar-src" name="avatar_src" type="hidden">
											<input class="avatar-data" name="avatar_data" type="hidden">
											<label for="avatarInput" style="line-height: 35px;">图片上传</label>
											<button class="btn btn-danger"  type="button" style="height: 35px;" onclick="$('input[id=avatarInput]').click();">请选择图片</button>
											<span id="avatar-name"></span>
											<input class="avatar-input hide" id="avatarInput" name="avatar_file" type="file"></div>
										<div class="row">
											<div class="col-md-9">
												<div class="avatar-wrapper"></div>
											</div>
											<div class="col-md-3">
												<div class="avatar-preview preview-lg" id="imageHead"></div>
												<!--<div class="avatar-preview preview-md"></div>
										<div class="avatar-preview preview-sm"></div>-->
											</div>
										</div>
										<div class="row avatar-btns">
											<div class="col-md-4">
												<div class="btn-group">
													<button class="btn btn-danger fa fa-undo" data-method="rotate" data-option="-90" type="button" title="Rotate -90 degrees"> 向左旋转</button>
												</div>
												<div class="btn-group">
													<button class="btn  btn-danger fa fa-repeat" data-method="rotate" data-option="90" type="button" title="Rotate 90 degrees"> 向右旋转</button>
												</div>
											</div>
											<div class="col-md-5" style="text-align: right;">								
												<button class="btn btn-danger fa fa-arrows" data-method="setDragMode" data-option="move" type="button" title="移动">
									            <span class="docs-tooltip" data-toggle="tooltip" title="" data-original-title="$().cropper(&quot;setDragMode&quot;, &quot;move&quot;)">
									            </span>
									          </button>
									          <button type="button" class="btn btn-danger fa fa-search-plus" data-method="zoom" data-option="0.1" title="放大图片">
									            <span class="docs-tooltip" data-toggle="tooltip" title="" data-original-title="$().cropper(&quot;zoom&quot;, 0.1)">
									              <!--<span class="fa fa-search-plus"></span>-->
									            </span>
									          </button>
									          <button type="button" class="btn btn-danger fa fa-search-minus" data-method="zoom" data-option="-0.1" title="缩小图片">
									            <span class="docs-tooltip" data-toggle="tooltip" title="" data-original-title="$().cropper(&quot;zoom&quot;, -0.1)">
									              <!--<span class="fa fa-search-minus"></span>-->
									            </span>
									          </button>
									          <button type="button" class="btn btn-danger fa fa-refresh" data-method="reset" title="重置图片">
										            <span class="docs-tooltip" data-toggle="tooltip" title="" data-original-title="$().cropper(&quot;reset&quot;)" aria-describedby="tooltip866214">
										       </button>
									        </div>
											<div class="col-md-3">
												<button class="btn btn-danger btn-block avatar-save fa fa-save" type="button" data-dismiss="modal"> 保存修改</button>
											</div>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
</div>

@stop