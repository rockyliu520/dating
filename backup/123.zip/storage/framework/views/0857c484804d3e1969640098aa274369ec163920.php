<div class="login-header-block">
	<div class="login_block">							
		
		<?php echo $__env->make('front.layouts.topbar.notification', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- <?php echo $__env->make('front.layouts.topbar.message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
		
		<div class="be-drop-down login-user-down">
			<?php if(Auth::user()->image == ''): ?>
				<img class="login-user" src="/img/login.jpg" alt="">
			<?php else: ?>
				<img class="login-user" src="<?php echo e(Auth::user()->image); ?>" alt="" style="width:40px;height:40px;">
			<?php endif; ?>
			&nbsp;&nbsp;&nbsp;
			<span class="be-dropdown-content">Hi, <span><?php echo e(Auth::user()->fname); ?>&nbsp;<?php echo e(Auth::user()->lname); ?></span></span>
			<div class="drop-down-list a-list" id="r_top_profile">
				<a href="/account/dashboard">我的资料</a>
				<!-- <a href="about-us.html">Work Experience</a> -->
				<a href="/account/profile">账户设置</a>
				<a href="/account/signout">登出账号</a>
			</div>
		</div>
	</div>
</div>