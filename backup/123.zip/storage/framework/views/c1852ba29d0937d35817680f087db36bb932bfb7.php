<h1>Click the Link To Verify Your Email</h1>
Click the following link to verify your email <?php echo e(url('account/verifyemail/'.$email_token)); ?>