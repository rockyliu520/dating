<a class="notofications-popup" href="page1.html">
	<i class="fa fa-bell-o"></i>
	<span class="noto-count">23</span>
</a>
<div class="noto-popup notofications-block">
	<div class="m-close"><i class="fa fa-times"></i></div>
	<div class="noto-label">网站消息</div>
	<div class="noto-body">
		<div class="noto-entry">
			<div class="noto-content clearfix">
				<div class="noto-img">	
					<a href="page1.html">
						<img src="/img/c1.png" alt="" class="be-ava-comment">
					</a>
				</div>
				<div class="noto-text">
					<div class="noto-text-top">
						<span class="noto-name"><a href="page1.html">Ravi Sah</a></span>
						<span class="noto-date"><i class="fa fa-clock-o"></i> May 27, 2015</span>
					</div>
					<a href="page1.html" class="noto-message">Start following your work</a>
				</div>
			</div>
		</div>
		<div class="noto-entry">
			<div class="noto-content clearfix">
				<div class="noto-img">	
					<a href="page1.html">
						<img src="/img/c6.jpg" alt="" class="be-ava-comment">
					</a>
				</div>
				<div class="noto-text">
					<div class="noto-text-top">
						<span class="noto-name"><a href="page1.html">Louis Paquet</a></span>
						<span class="noto-date"><i class="fa fa-clock-o"></i> May 27, 2015</span>
					</div>
					<div class="noto-message">
						Saved “<a href="page1.html">Omni-onepage app template</a>” to Inspiration
						<a class="portfolio-link type-2 clearfix" href="page1.html">
							<img src="/img/p_link_23.jpg" alt="">
							<img src="/img/p_link_31.jpg" alt="">
							<img src="/img/p_link_32.jpg" alt="">
							<img src="/img/p_link_33.jpg" alt="">
							<img src="/img/p_link_34.jpg" alt="">
							<div class="color_bg">
								<span>view portfolio</span>
								<span class="child"></span>
							</div>
						</a>
					</div>
				</div>
			</div>
		</div>
		<div class="noto-entry">
			<div class="noto-content clearfix">
				<div class="noto-img">	
					<a href="page1.html">
						<img src="/img/c7.jpg" alt="" class="be-ava-comment">
					</a>
				</div>
				<div class="noto-text">
					<div class="noto-text-top">
						<span class="noto-name"><a href="page1.html">v-a studio</a></span>
						<span class="noto-date"><i class="fa fa-clock-o"></i> May 27, 2015</span>
					</div>
					<div class="noto-message">
						<a class="noto-left" href="page1.html">
							<img src="/img/n_pop_1.jpg" alt="">
						</a>
						Saved “<a href="page1.html">Omni-onepage app template</a>” to Inspiration
					</div>
				</div>
			</div>
		</div>
		<div class="noto-entry">
			<div class="noto-content clearfix">
				<div class="noto-img">	
					<a href="page1.html">
						<img src="/img/c8.jpg" alt="" class="be-ava-comment">
					</a>
				</div>
				<div class="noto-text">
					<div class="noto-text-top">
						<span class="noto-name"><a href="page1.html">Hoang Nguyen</a></span>
						<span class="noto-date"><i class="fa fa-clock-o"></i> May 27, 2015</span>
					</div>
					<div class="noto-message">
						<a class="noto-left" href="page1.html">
							<img src="/img/n_pop_2.jpg" alt="">
						</a>
						Awesome, love the big whitespace and also everything between :)
					</div>
				</div>
			</div>
		</div>
		<div class="noto-entry">
			<div class="noto-content clearfix">
				<div class="noto-img">	
					<a href="page1.html">
						<img src="/img/c9.jpg" alt="" class="be-ava-comment">
					</a>
				</div>
				<div class="noto-text">
					<div class="noto-text-top">
						<span class="noto-name"><a href="page1.html">Cüneyt ŞEN</a></span>
						<span class="noto-date"><i class="fa fa-clock-o"></i> May 27, 2015</span>
					</div>
					<a href="page1.html" class="noto-message">
						Start following your work
					</a>
				</div>
			</div>
		</div>												
	</div>							
</div>