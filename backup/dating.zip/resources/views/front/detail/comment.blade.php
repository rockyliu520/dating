<div class="be-comment-block">
	<h1 class="comments-title">Comments (3)</h1>
	<p class="about-comment-block">
		You must <a href="blog-detail-2.html" class="be-signup-link">SIGN UP</a>
		 to join the conversation.
	</p>
	<div class="be-comment">
			<div class="be-img-comment">	
				<a href="blog-detail-2.html">
					<img src="/img/c1.png" alt="" class="be-ava-comment">
				</a>
			</div>
			<div class="be-comment-content">
				
					<span class="be-comment-name">
						<a href="blog-detail-2.html">Ravi Sah</a>
						</span>
					<span class="be-comment-time">
						<i class="fa fa-clock-o"></i>
						May 27, 2015 at 3:14am
					</span>

				<p class="be-comment-text">
					Pellentesque gravida tristique ultrices. 
					Sed blandit varius mauris, vel volutpat urna hendrerit id. 
					Curabitur rutrum dolor gravida turpis tristique efficitur.
				</p>
			</div>
			
		</div>
	<div class="be-comment">
		<div class="be-img-comment">	
				<a href="blog-detail-2.html">
					<img src="/img/c2.png" alt="" class="be-ava-comment">
				</a>
			</div>
			<div class="be-comment-content">
				
					<span class="be-comment-name">
						<a href="blog-detail-2.html">Phoenix, the Creative Studio</a>
				</span>
					<span class="be-comment-time">
						<i class="fa fa-clock-o"></i>
						May 27, 2015 at 3:14am
					</span>

				<p class="be-comment-text">
					Nunc ornare sed dolor sed mattis. In scelerisque dui a arcu mattis, at maximus eros commodo. Cras magna nunc, cursus lobortis luctus at, sollicitudin vel neque. Duis eleifend lorem non ant. Proin ut ornare lectus, vel eleifend est. Fusce hendrerit dui in turpis tristique blandit.
				</p>
				</div>
			
		</div>
	<div class="be-comment">
		<div class="be-img-comment">	
				<a href="blog-detail-2.html">
					<img src="/img/c3.png" alt="" class="be-ava-comment">
				</a>
			</div>
			<div class="be-comment-content">
					<span class="be-comment-name">
						<a href="blog-detail-2.html">Dorian Camp</a>
				</span>
					<span class="be-comment-time">
						<i class="fa fa-clock-o"></i>
						May 27, 2015 at 3:14am
					</span>
				<p class="be-comment-text">
					Cras magna nunc, cursus lobortis luctus at, sollicitudin vel neque. Duis eleifend lorem non ant
				</p>
			</div>
	</div>
</div>