<form action="/account/login" method="post" class="popup-input-search">
	{{ csrf_field() }}
	<div class="col-md-12 noPadding">
		<input class="input-signtype" type="email" name="email" required="required" placeholder="邮箱">
	</div>
	<div class="col-md-12 noPadding">
		<input class="input-signtype" type="password" name="password" required="required" placeholder="密码">
	</div>
	<div class="col-xs-12 noPadding">
		<div class="be-checkbox">
		<label class="check-box">
			    <input class="checkbox-input" type="checkbox" value=""> <span class="check-box-sign"></span>
			</label>
			<span class="large-popup-text">
				保持登录
			</span>
		</div>
		<div class="r_forget_password">
			<a href="/account/forget" class="link-large-popup">忘记密码?</a>
		</div>
		<div class="clearfix"></div>
	</div>
	@if(Session::has('loginError'))
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 noPadding">
		<div class="alert alert-danger">
			{{ Session::get('loginError') }}
		</div>
	</div>
	@endif
	<div class="col-md-12 for-signin noPadding">
		<input type="submit" class="be-popup-sign-button btn-block" value="现在登录">
	</div>
</form>
